# Malforth Castle — Outer Grounds Area Breakdown

## Area Overview
**Area Name:** Outer Grounds of Malforth Castle  
**Theme:** Threshold, isolation, creeping unease  
**Player Role:** Arriving adventurer from the wider world

The Outer Grounds serve as the adventurer’s first contact with Malforth Castle. This area establishes tone, teaches exploration expectations, and presents multiple non-punitive paths toward deeper areas of the domain.

Design emphasis is on **atmosphere over danger**, with subtle environmental storytelling and early foreshadowing of the castle’s mystery.

---

## OG-01: The Old Road to Malforth

**Description**  
A narrow, cracked stone road winds through sparse woodland toward a looming silhouette in the distance. The castle’s towers rise above the trees, half-lost in drifting fog. The air is colder here than it should be.

**Exits**
- `north` → OG-02: Fog-Choked Approach
- `south` → Back to the larger world

**Notable Details**
- Wind carries faint, indistinct sounds
- Tracks appear briefly, then vanish

**Purpose**
- Arrival room
- Safe retreat point
- Establishes isolation and scale

---

## OG-02: Fog-Choked Approach

**Description**  
Fog thickens along the road, clinging to the ground and obscuring the base of the castle walls. The road here feels less traveled, as though few choose to go farther.

**Exits**
- `south` → OG-01: Old Road
- `north` → OG-03: Outer Wall
- `west` → OG-04: Overgrown Hedgerow Path

**Notable Details**
- Shifting fog messages
- Sounds without visible sources

**Purpose**
- First branching decision
- Introduces environmental unease

---

## OG-03: The Outer Wall

**Description**  
A massive stone wall rises before you, its surface cracked and veined with ivy. Portions have collapsed into rubble, leaving gaps large enough to pass through. The main gate stands ahead, crooked and unguarded.

**Exits**
- `south` → OG-02: Fog-Choked Approach
- `north` → OG-07: Gatehouse Ruins
- `east` → OG-05: Broken Curtain Wall

**Notable Details**
- Weathered carvings worn beyond recognition
- Stone surface feels watched

**Purpose**
- First clear view of castle defenses
- Establishes abandonment and decay

---

## OG-04: Overgrown Hedgerow Path

**Description**  
A narrow path forces its way through thorny hedges and wild growth. Brambles tug at your clothes as if reluctant to let you pass. The castle is partially hidden from view here.

**Exits**
- `east` → OG-02: Fog-Choked Approach
- `north` → OG-06: Garden Perimeter

**Notable Details**
- Flavor text suggesting resistance to passage
- Minor cosmetic scrapes or torn fabric

**Purpose**
- Optional exploration route
- Rewards curiosity

---

## OG-05: Broken Curtain Wall

**Description**  
Here the outer wall has collapsed entirely, spilling stone into a shallow ditch. Beyond the breach, the castle courtyard is visible through drifting mist.

**Exits**
- `west` → OG-03: Outer Wall
- `north` → CC-01: Castle Courtyard

**Notable Details**
- First glimpse inside the castle proper
- Wind whistling through broken stone

**Purpose**
- Alternate castle entrance
- Reinforces vulnerability of the structure

---

## OG-06: Garden Perimeter

**Description**  
Stone markers and half-buried edging hint that this was once a tended garden. Now it is wild and tangled, with vines crawling over low walls and cracked paths.

**Exits**
- `south` → OG-04: Overgrown Hedgerow Path
- `north` → FG-01: Formal Gardens

**Notable Details**
- Statues barely visible through foliage
- Lingering scent of old flowers

**Purpose**
- Transitional space into the Formal Gardens
- Early beauty-versus-decay contrast

---

## OG-07: Gatehouse Ruins

**Description**  
The gatehouse stands in ruin. The portcullis lies twisted on the ground, and the guard towers are empty shells. The massive gates hang open, creaking softly in the wind.

**Exits**
- `south` → OG-03: Outer Wall
- `north` → CC-01: Castle Courtyard
- `west` → OG-08: Old Watch Post

**Notable Details**
- Rusted weapons and broken shields
- No signs of struggle—only abandonment

**Purpose**
- Primary entrance into the castle
- Symbol of failed protection

---

## OG-08: Old Watch Post

**Description**  
A small guard post tucked against the wall. A single chair lies overturned. Scratches mark the stone floor, as though something was dragged away.

**Exits**
- `east` → OG-07: Gatehouse Ruins
- `north` → CM-01: Family Cemetery

**Notable Details**
- First explicitly unsettling physical clue
- Optional lore object (journal fragment, insignia)

**Purpose**
- Narrative transition toward the cemetery
- Introduces mystery elements

---

## OG-09: Cemetery Gate (Optional Buffer Room)

**Description**  
An iron gate stands open, its hinges frozen in place. Beyond it lies a small family cemetery, the headstones pale against dark earth.

**Exits**
- `south` → OG-08: Old Watch Post
- `north` → CM-01: Family Cemetery

**Purpose**
- Psychological threshold into death-themed content
- Pacing buffer before heavier atmosphere

---

## Area Summary

**Narrative Function**
- Establishes the haunted tone
- Presents choice without punishment
- Foreshadows deeper mysteries

**Mechanical Expectations Set**
- Exploration over combat
- Observation matters
- Backtracking is natural and safe

---

*Document version: Outer Grounds layout draft*

