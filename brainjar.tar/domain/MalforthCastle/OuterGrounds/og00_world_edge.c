inherit "/std/room.c";

void create() {
    ::create();
    setup_base(
        "Road to the Wider World",
        "The cracked stone road continues south, slipping back toward the wider world beyond Malforth's woods. The trees thin there, and the fog loosens its grip, as if the castle's shadow refuses to follow.",
        ([ "north": "/domain/MalforthCastle/OuterGrounds/og01_old_road.c" ])
    );
}
