inherit "/std/room.c";

void create() {
    ::create();
    setup_base(
        "The Old Road to Malforth",
        "A narrow, cracked stone road winds through sparse woodland toward a looming silhouette in the distance. The castle's towers rise above the trees, half-lost in drifting fog. The air is colder here than it should be.",
        ([
            "north": "/domain/MalforthCastle/OuterGrounds/og02_fog_choked_approach.c",
            "south": "/domain/MalforthCastle/OuterGrounds/og00_world_edge.c"
        ])
    );
}
