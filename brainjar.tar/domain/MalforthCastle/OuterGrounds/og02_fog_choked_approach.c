inherit "/std/room.c";

void create() {
    ::create();
    setup_base(
        "Fog-Choked Approach",
        "Fog thickens along the road, clinging to the ground and obscuring the base of the castle walls. The path here feels less traveled, as though few choose to go farther, and the mist shifts at the edge of sight.",
        ([
            "south": "/domain/MalforthCastle/OuterGrounds/og01_old_road",
            "north": "/domain/MalforthCastle/OuterGrounds/og03_outer_wall",
            "west": "/domain/MalforthCastle/OuterGrounds/og04_hedgerow_path",
        ])
    );
}
