inherit "/std/room.c";

void create() {
    ::create();
    setup_base(
        "The Outer Wall",
        "A massive stone wall rises before you, its surface cracked and veined with ivy. Portions have collapsed into rubble, leaving gaps large enough to pass through. The main gate stands ahead, crooked and unguarded.",
        ([
            "south": "/domain/MalforthCastle/OuterGrounds/og02_fog_choked_approach",
            "north": "/domain/MalforthCastle/OuterGrounds/og07_gatehouse_ruins",
            "east": "/domain/MalforthCastle/OuterGrounds/og05_broken_curtain_wall",
        ])
    );
}
