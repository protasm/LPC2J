inherit "/std/room.c";

void create() {
    ::create();
    setup_base(
        "Overgrown Hedgerow Path",
        "A narrow path forces its way through thorny hedges and wild growth. Brambles tug at your clothes as if reluctant to let you pass. The castle is partially hidden from view here behind tangled green.",
        ([
            "east": "/domain/MalforthCastle/OuterGrounds/og02_fog_choked_approach",
            "north": "/domain/MalforthCastle/OuterGrounds/og06_garden_perimeter",
        ])
    );
}
