inherit "/std/room.c";

void create() {
    ::create();
    setup_base(
        "Broken Curtain Wall",
        "Here the outer wall has collapsed entirely, spilling stone into a shallow ditch. Beyond the breach, the castle courtyard is visible through drifting mist, and wind whistles through broken stone.",
        ([
            "west": "/domain/MalforthCastle/OuterGrounds/og03_outer_wall",
            "north": "/domain/MalforthCastle/CastleCourtyard/cc01_courtyard",
        ])
    );
}
