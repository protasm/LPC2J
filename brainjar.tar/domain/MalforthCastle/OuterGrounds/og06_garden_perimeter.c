inherit "/std/room.c";

void create() {
    ::create();
    setup_base(
        "Garden Perimeter",
        "Stone markers and half-buried edging hint that this was once a tended garden. Now it is wild and tangled, with vines crawling over low walls and cracked paths. Pale statues linger behind the foliage.",
        ([
            "south": "/domain/MalforthCastle/OuterGrounds/og04_hedgerow_path",
            "north": "/domain/MalforthCastle/FormalGardens/fg01_formal_gardens",
        ])
    );
}
