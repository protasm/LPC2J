inherit "/std/room.c";

void create() {
    ::create();
    setup_base(
        "Gatehouse Ruins",
        "The gatehouse stands in ruin. The portcullis lies twisted on the ground, and the guard towers are empty shells. The massive gates hang open, creaking softly in the wind.",
        ([
            "south": "/domain/MalforthCastle/OuterGrounds/og03_outer_wall",
            "north": "/domain/MalforthCastle/CastleCourtyard/cc01_courtyard",
            "west": "/domain/MalforthCastle/OuterGrounds/og08_old_watch_post",
        ])
    );
}
