inherit "/std/room.c";

void create() {
    ::create();
    setup_base(
        "Old Watch Post",
        "A small guard post tucked against the wall. A single chair lies overturned, and scratches mark the stone floor as though something was dragged away. Rusted weapons and broken shields are scattered in the dust.",
        ([
            "east": "/domain/MalforthCastle/OuterGrounds/og07_gatehouse_ruins",
            "north": "/domain/MalforthCastle/OuterGrounds/og09_cemetery_gate",
        ])
    );
}
