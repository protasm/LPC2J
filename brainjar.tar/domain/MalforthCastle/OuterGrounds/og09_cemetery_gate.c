inherit "/std/room.c";

void create() {
    ::create();
    setup_base(
        "Cemetery Gate",
        "An iron gate stands open, its hinges frozen in place. Beyond it lies a small family cemetery, the headstones pale against dark earth. The air grows still as you approach.",
        ([
            "south": "/domain/MalforthCastle/OuterGrounds/og08_old_watch_post",
            "north": "/domain/MalforthCastle/FamilyCemetery/cm01_cemetery",
        ])
    );
}
