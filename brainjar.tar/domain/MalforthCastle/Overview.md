# Malforth Castle — LPMud Domain Design Overview

## Purpose
Malforth Castle is an LPC/LPMud domain designed as a **self-contained haunted castle** featuring a mystery-driven ghost story. The domain emphasizes atmosphere, environmental storytelling, exploration loops, and gradual revelation rather than linear questing. While suitable for MUD gameplay, the design avoids hard dependence on MUD-specific tropes so it can also serve as a narrative exploration domain.

This document captures **all design decisions made so far**, focusing on *physical layout and interconnections*. Story, NPCs, and item mechanics will be layered on top later.

---

## Design Principles

- **Exploration-first**: Multiple paths, loops, and rediscovery.
- **Verticality**: Towers above, secrets below.
- **Soft gating**: Locks are narrative or environmental, not arbitrary.
- **Environmental storytelling**: Rooms, names, and layout tell the story.
- **No dead ends** (except where intentional).

---

## High-Level Structure

Malforth Castle is organized into **three vertical layers**:

1. **Upper / Exterior** — air, wind, watchfulness, isolation
2. **Main / Surface** — daily life, power, ceremony
3. **Lower / Subterranean** — secrets, guilt, ancient forces

These layers are interconnected via multiple routes to avoid strict linear progression.

---

## Area List (12 Major Areas)

### 1. Outer Grounds
**Theme:** Threshold and unease

- Castle approach road
- Overgrown hedgerows
- Broken outer walls
- Ruined gatehouse
- Fog pockets and wind

**Connections:**
- → Castle Courtyard
- → Formal Gardens
- → Family Cemetery

---

### 2. Castle Courtyard (Central Hub)
**Theme:** Exposure and echoes

- Central open space
- Dry fountain or well
- Barracks remnants
- Multiple wing entrances

**Connections:**
- ← Outer Grounds
- → Great Hall
- → Residential Wing
- → Dungeons & Holding Cells
- → Keep & Battlements
- → Formal Gardens

---

### 3. Formal Gardens
**Theme:** Beauty turned uncanny

- Overgrown rose beds
- Stone paths
- Gazebo / pavilion
- Hedge maze (optional)
- Weathered statues

**Connections:**
- ← Outer Grounds
- ← Castle Courtyard
- → Family Cemetery
- → Chapel & Reliquary
- → Underground Crypts (hidden entrance)

---

### 4. Family Cemetery
**Theme:** Restlessness of the dead

- Family mausoleum
- Individual headstones
- Sunken graves
- Whispering winds

**Connections:**
- ← Outer Grounds
- ← Formal Gardens
- → Underground Crypts (mausoleum stairs)

---

### 5. Great Hall
**Theme:** Fallen grandeur

- Long banquet tables
- High dais
- Tattered banners
- Grand fireplace
- Shadowed balconies

**Connections:**
- ← Castle Courtyard
- → Residential Wing
- → Chapel & Reliquary
- → Keep & Battlements (balcony stair)

---

### 6. Residential Wing
**Theme:** Interrupted lives

- Noble bedchambers
- Servants’ quarters
- Children’s rooms
- Personal effects and journals

**Connections:**
- ← Castle Courtyard
- ← Great Hall
- → Chapel & Reliquary
- → Dungeons & Holding Cells (secret passage)

---

### 7. Chapel & Reliquary
**Theme:** Faith under strain

- Chapel nave
- Altar
- Confessional
- Reliquary chamber
- Altered or desecrated symbols

**Connections:**
- ← Great Hall
- ← Formal Gardens
- ← Residential Wing
- → Underground Crypts (sanctified stairs)

---

### 8. Dungeons & Holding Cells
**Theme:** Authority and cruelty

- Prison cells
- Interrogation chamber
- Broken restraints
- Evidence of unrest

**Connections:**
- ← Castle Courtyard
- ← Residential Wing (secret)
- → Underground Crypts
- → Caves & Grotto (collapsed wall / drainage tunnel)

---

### 9. Underground Crypts & Catacombs
**Theme:** Memory and ancestry

- Narrow tunnels
- Ancestral tombs
- Ossuaries
- Collapsed passages

**Connections:**
- ← Family Cemetery
- ← Formal Gardens (hidden)
- ← Chapel & Reliquary
- ← Dungeons & Holding Cells
- → Caves & Grotto

---

### 10. Caves & Grotto Beneath the Castle
**Theme:** Something older than Malforth

- Natural caverns
- Underground stream
- Luminescent fungi
- Ancient stonework

**Connections:**
- ← Underground Crypts
- ← Dungeons & Holding Cells
- → Sealed chamber / finale area (optional)

---

### 11. Keep & Battlements
**Theme:** Vigilance and isolation

- Spiral staircases
- Wall walks
- Guard towers
- Arrow slits

**Connections:**
- ← Castle Courtyard
- ← Great Hall
- → Belfry & Bell Tower

---

### 12. Belfry & Bell Tower
**Theme:** Sound that should not ring

- Narrow ladders
- Wooden platforms
- Rotted ropes
- The great bell

**Connections:**
- ← Keep & Battlements

**Notes:**
- Intentionally isolated
- Bell acts as a world-state trigger

---

## Connectivity Overview (Conceptual)

```
Outer Grounds
   ├── Courtyard ── Great Hall ── Keep ── Belfry
   │        │           │
   │        │           └── Chapel
   │        │                │
   │        ├── Residential ─┘
   │        │
   │        └── Dungeons ── Crypts ── Caves
   │
   ├── Gardens ── Cemetery ── Crypts
   │      │
   │      └── Chapel
```

---

## Current State

This document defines:
- The **full physical layout** of Malforth Castle
- All **major areas** and their purposes
- All **primary and secondary interconnections**
- The **structural foundation** for mystery and haunting

It intentionally does **not yet define**:
- NPCs
- Quests
- Items
- Ghost mechanics
- Story resolution

Those will be layered on top of this layout.

---

## Suggested Next Steps

- Room-by-room breakdown of a single area (e.g., Great Hall complex)
- Secret passages and unlock conditions
- Central mystery timeline
- NPC ghosts and recurring encounters
- LPC room skeletons for one wing

---

*Document version: initial layout draft*

