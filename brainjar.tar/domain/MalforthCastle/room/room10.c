inherit "/std/room.c";

void create() {
    ::create();
    setup_base("Castle room 10", "An arched corridor lined with carved pillars. The air smells faintly of old parchment and iron, suggesting nearby armories and libraries.", ([ "west": "/domain/MalforthCastle/room/room9", "north": "/domain/MalforthCastle/room/room5", "south": "/domain/MalforthCastle/room/room15", "up": "/domain/MalforthCastle/room/room35" ]));
}
