inherit "/std/room.c";

void create() {
    ::create();
    setup_base("Castle room 12", "An arched corridor lined with carved pillars. The air smells faintly of old parchment and iron, suggesting nearby armories and libraries.", ([ "west": "/domain/MalforthCastle/room/room11", "east": "/domain/MalforthCastle/room/room13", "north": "/domain/MalforthCastle/room/room7", "south": "/domain/MalforthCastle/room/room17", "up": "/domain/MalforthCastle/room/room37" ]));
}
