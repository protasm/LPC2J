inherit "/std/room.c";

void create() {
    ::create();
    setup_base("Castle room 16", "An arched corridor lined with carved pillars. The air smells faintly of old parchment and iron, suggesting nearby armories and libraries.", ([ "east": "/domain/MalforthCastle/room/room17", "north": "/domain/MalforthCastle/room/room11", "south": "/domain/MalforthCastle/room/room21", "up": "/domain/MalforthCastle/room/room41" ]));
}
