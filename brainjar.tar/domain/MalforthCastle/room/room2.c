inherit "/std/room.c";

void create() {
    ::create();
    setup_base("Castle room 2", "An arched corridor lined with carved pillars. The air smells faintly of old parchment and iron, suggesting nearby armories and libraries.", ([ "west": "/domain/MalforthCastle/room/room1", "east": "/domain/MalforthCastle/room/room3", "south": "/domain/MalforthCastle/room/room7", "up": "/domain/MalforthCastle/room/room27" ]));
}
