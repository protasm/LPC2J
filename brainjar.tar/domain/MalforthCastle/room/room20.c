inherit "/std/room.c";

void create() {
    ::create();
    setup_base("Castle room 20", "An arched corridor lined with carved pillars. The air smells faintly of old parchment and iron, suggesting nearby armories and libraries.", ([ "west": "/domain/MalforthCastle/room/room19", "north": "/domain/MalforthCastle/room/room15", "south": "/domain/MalforthCastle/room/room25", "up": "/domain/MalforthCastle/room/room45" ]));
}
