inherit "/std/room.c";

void create() {
    ::create();
    setup_base("Castle room 23", "A stone chamber within the winding halls of Malforth Castle. Tapestries and torches lend a medieval glow, and stairwells hint at deeper heights and depths.", ([ "west": "/domain/MalforthCastle/room/room22", "east": "/domain/MalforthCastle/room/room24", "north": "/domain/MalforthCastle/room/room18", "up": "/domain/MalforthCastle/room/room48" ]));
}
