inherit "/std/room.c";

void create() {
    ::create();
    setup_base("Castle room 28", "An arched corridor lined with carved pillars. The air smells faintly of old parchment and iron, suggesting nearby armories and libraries.", ([ "west": "/domain/MalforthCastle/room/room27", "east": "/domain/MalforthCastle/room/room29", "south": "/domain/MalforthCastle/room/room33", "down": "/domain/MalforthCastle/room/room3" ]));
}
