inherit "/std/room.c";

void create() {
    ::create();
    setup_base("Castle room 30", "An arched corridor lined with carved pillars. The air smells faintly of old parchment and iron, suggesting nearby armories and libraries.", ([ "west": "/domain/MalforthCastle/room/room29", "south": "/domain/MalforthCastle/room/room35", "down": "/domain/MalforthCastle/room/room5" ]));
}
