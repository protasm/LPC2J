inherit "/std/room.c";

void create() {
    ::create();
    setup_base("Castle room 32", "An arched corridor lined with carved pillars. The air smells faintly of old parchment and iron, suggesting nearby armories and libraries.", ([ "west": "/domain/MalforthCastle/room/room31", "east": "/domain/MalforthCastle/room/room33", "north": "/domain/MalforthCastle/room/room27", "south": "/domain/MalforthCastle/room/room37", "down": "/domain/MalforthCastle/room/room7" ]));
}
