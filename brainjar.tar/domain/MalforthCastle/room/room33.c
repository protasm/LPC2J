inherit "/std/room.c";

void create() {
    ::create();
    setup_base("Castle room 33", "A stone chamber within the winding halls of Malforth Castle. Tapestries and torches lend a medieval glow, and stairwells hint at deeper heights and depths.", ([ "west": "/domain/MalforthCastle/room/room32", "east": "/domain/MalforthCastle/room/room34", "north": "/domain/MalforthCastle/room/room28", "south": "/domain/MalforthCastle/room/room38", "down": "/domain/MalforthCastle/room/room8" ]));
}
