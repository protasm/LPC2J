inherit "/std/room.c";

void create() {
    ::create();
    setup_base("Castle room 35", "A stone chamber within the winding halls of Malforth Castle. Tapestries and torches lend a medieval glow, and stairwells hint at deeper heights and depths.", ([ "west": "/domain/MalforthCastle/room/room34", "north": "/domain/MalforthCastle/room/room30", "south": "/domain/MalforthCastle/room/room40", "down": "/domain/MalforthCastle/room/room10" ]));
}
