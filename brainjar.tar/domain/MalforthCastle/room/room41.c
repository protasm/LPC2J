inherit "/std/room.c";

void create() {
    ::create();
    setup_base("Castle room 41", "A stone chamber within the winding halls of Malforth Castle. Tapestries and torches lend a medieval glow, and stairwells hint at deeper heights and depths.", ([ "east": "/domain/MalforthCastle/room/room42", "north": "/domain/MalforthCastle/room/room36", "south": "/domain/MalforthCastle/room/room46", "down": "/domain/MalforthCastle/room/room16" ]));
}
