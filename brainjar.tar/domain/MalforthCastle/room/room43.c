inherit "/std/room.c";

void create() {
    ::create();
    setup_base("Castle room 43", "A stone chamber within the winding halls of Malforth Castle. Tapestries and torches lend a medieval glow, and stairwells hint at deeper heights and depths.", ([ "west": "/domain/MalforthCastle/room/room42", "east": "/domain/MalforthCastle/room/room44", "north": "/domain/MalforthCastle/room/room38", "south": "/domain/MalforthCastle/room/room48", "down": "/domain/MalforthCastle/room/room18" ]));
}
