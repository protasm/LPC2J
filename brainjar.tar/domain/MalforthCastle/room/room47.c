inherit "/std/room.c";

void create() {
    ::create();
    setup_base("Castle room 47", "A stone chamber within the winding halls of Malforth Castle. Tapestries and torches lend a medieval glow, and stairwells hint at deeper heights and depths.", ([ "west": "/domain/MalforthCastle/room/room46", "east": "/domain/MalforthCastle/room/room48", "north": "/domain/MalforthCastle/room/room42", "down": "/domain/MalforthCastle/room/room22" ]));
}
