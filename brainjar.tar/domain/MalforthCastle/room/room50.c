inherit "/std/room.c";

void create() {
    ::create();
    setup_base("Castle room 50", "An arched corridor lined with carved pillars. The air smells faintly of old parchment and iron, suggesting nearby armories and libraries.", ([ "west": "/domain/MalforthCastle/room/room49", "north": "/domain/MalforthCastle/room/room45", "down": "/domain/MalforthCastle/room/room25" ]));
}
