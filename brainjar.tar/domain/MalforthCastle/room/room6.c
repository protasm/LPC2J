inherit "/std/room.c";

void create() {
    ::create();
    setup_base("Castle room 6", "An arched corridor lined with carved pillars. The air smells faintly of old parchment and iron, suggesting nearby armories and libraries.", ([ "east": "/domain/MalforthCastle/room/room7", "north": "/domain/MalforthCastle/room/room1", "south": "/domain/MalforthCastle/room/room11", "up": "/domain/MalforthCastle/room/room31" ]));
}
