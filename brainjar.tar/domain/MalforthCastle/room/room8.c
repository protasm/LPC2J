inherit "/std/room.c";

void create() {
    ::create();
    setup_base("Castle room 8", "An arched corridor lined with carved pillars. The air smells faintly of old parchment and iron, suggesting nearby armories and libraries.", ([ "west": "/domain/MalforthCastle/room/room7", "east": "/domain/MalforthCastle/room/room9", "north": "/domain/MalforthCastle/room/room3", "south": "/domain/MalforthCastle/room/room13", "up": "/domain/MalforthCastle/room/room33" ]));
}
