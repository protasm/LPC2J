string object_id;

void create() {
    object_id = "" + next_object_id();
}

string query_id() {
    return object_id;
}
