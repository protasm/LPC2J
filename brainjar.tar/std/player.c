inherit "/std/base_object.c";

string name;
object location;
string location_path;
string pending_move;

void set_name(string new_name) {
    name = new_name;
}

string query_name() {
    return name;
}

void set_location(object room, string room_path) {
    location = room;
    location_path = room_path;
}

string query_location() {
    return location_path;
}

object query_location_object() {
    return location;
}

string consume_pending_move() {
    string next_room = pending_move;

    pending_move = 0;

    return next_room;
}

string format_exits(mapping exits) {
    string *directions;
    string summary;
    int i;

    directions = keys(exits);

    if (!sizeof(directions)) {
        return "Exits: none.";
    }

    summary = "Exits: " + directions[0];

    for (i = 1; i < sizeof(directions); i++) {
        summary += ", " + directions[i];
    }

    return summary + ".";
}

string look() {
    string short_desc;
    string long_desc;
    mapping exits;

    if (!location) {
        return "You are nowhere.";
    }

    short_desc = location->query_short();
    long_desc = location->query_long();
    exits = location->query_exits();

    return short_desc + "\r\n" + long_desc + "\r\n" + format_exits(exits) + "\r\n";
}

string handle_input(string input) {
    string command;
    string *parts;
    int i;
    mapping exits;

    if (!input) {
        return "Please enter a command [1].";
    }
    
    if (input == "") {
      return ("Please enter a command [2].");
    }

    command = lower_case(input);
    parts = explode(command, " ");
    command = "";

    for (i = 0; i < sizeof(parts); i++) {
        if (parts[i] != "") {
            command = parts[i];

            break;
        }
    }

    if (command == "") {
        return "Please enter a command [3].";
    }

    if (command == "look") {
        return look();
    }

    exits = location ? location->query_exits() : 0;

    if (exits) {
        string next_room;
        object next_room_object;

        next_room = exits[command];

        if (next_room) {
            if (location) {
                location->remove_player(this_object());
            }

            next_room_object = load_object(next_room);
            next_room_object->create();

            set_location(next_room_object, next_room);
            next_room_object->add_player(this_object());

            pending_move = 0;

            return look();
        }
    }

    return "I don't know how to go that way.";
}
