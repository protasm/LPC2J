inherit "/std/base_object.c";

string short_desc;
string long_desc;
mapping exits = ([ ]);
mapping players = ([ ]);

void set_short(string description) {
    short_desc = description;
}

void set_long(string description) {
    long_desc = description;
}

void set_exits(mapping exits_map) {
    exits = exits_map;
}

string query_short() {
    return short_desc;
}

string query_long() {
    return long_desc;
}

mapping query_exits() {
    return exits;
}

void add_player(object player) {
    if (!player) {
        return;
    }

    players[player->query_id()] = player;
}

void remove_player(object player) {
    mixed *player_keys;
    mapping updated;
    int i;

    if (!player) {
        return;
    }

    updated = ([ ]);
    player_keys = keys(players);

    for (i = 0; i < sizeof(player_keys); i++) {
        if (player_keys[i] != player->query_id()) {
            updated[player_keys[i]] = players[player_keys[i]];
        }
    }

    players = updated;
}

mapping query_players() {
    return players;
}

void setup_base(string short_desc, string long_desc, mapping exits_map) {
    set_short(short_desc);
    set_long(long_desc);
    set_exits(exits_map);
}
