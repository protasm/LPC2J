inherit "/std/base_object.c";

string start_room;
mapping players = ([ ]);

void game_startup() {
  start_room = "/domain/MalforthCastle/OuterGrounds/og00_world_edge.c";
}

string game_on_connect(object session) {
    return "/std/player.c";
}

string game_on_session_start(object session, object player) {
    object room;

    players[player->query_id()] = player;

    room = load_object(start_room);
    room -> create();

    player->set_location(room, start_room);
    room->add_player(player);

    return player->handle_input("look");
}

string game_on_input(object session, object player, string input) {
    return player->handle_input(input);
}

void game_on_disconnect(object session, object player) {
    object room;

    players[player->query_id()] = 0;

    room = player->query_location_object();

    if (room) {
        room->remove_player(player);
    }
}
