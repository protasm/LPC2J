inherit "/Users/jonathan/Projects/LPCDemo/src/main/java/io/github/protasm/lpcdemo/bar.c";

int foo() {
  return 101;
}
