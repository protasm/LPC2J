inherit "bar.c";

int foo() {
  return 101;
}
