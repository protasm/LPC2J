package io.github.protasm.lpcdemo;

import io.github.protasm.lpc2j.exec.LpcObjectHandle;
import io.github.protasm.lpc2j.exec.LpcRuntime;
import io.github.protasm.lpc2j.exec.LpcRuntimeConfig;

import java.lang.reflect.Method;
import java.nio.file.Path;

public final class LPCDemo {
    public static void main(String[] args) throws Exception {
        Path sourcePath = args.length > 0
                ? Path.of(args[0])
                : Path.of("foo.c");

        Path resolvedSourcePath = sourcePath.isAbsolute()
                ? sourcePath
                : Path.of("").toAbsolutePath().resolve(sourcePath).normalize();
        Path baseIncludePath = resolvedSourcePath.getParent();
        if (baseIncludePath == null) {
            baseIncludePath = Path.of("").toAbsolutePath();
        }

        LpcRuntime runtime = new LpcRuntime(
                LpcRuntimeConfig.builder()
                        .baseIncludePath(baseIncludePath)
                        .build()
        );

        // Load the LPC object (compiles + defines + instantiates).
        LpcObjectHandle foo = runtime.load(resolvedSourcePath);

        // Run any reflection / method calls with the runtime context set.
        foo.runWithRuntimeContext(() -> {
            try {
                Method bar = foo.objectClass().getMethod("bar");
                Object x = bar.invoke(foo.instance());
                System.out.println(foo.instance().getClass().getName());
                System.out.println("bar() invoked successfully.");
                System.out.println(x);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
    }
}
